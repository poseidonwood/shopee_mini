<!-- Footer Nav-->
<div class="footer-nav-area" id="footerNav">
  <div class="suha-footer-nav h-100">
    <ul class="h-100 d-flex align-items-center justify-content-between">
      <li class="active">
        <a href="<?= base_url(); ?>"><i class="lni-home"></i>Home</a>
      </li>
      <li>
        <a href="message.html"><i class="lni-support"></i>Support</a>
      </li>
      <li>
        <a href="cart.html"><i class="lni-cart"></i>Cart</a>
      </li>
      <li>
        <a href="pages.html"><i class="lni-heart"></i>Pages</a>
      </li>
      <li>
        <a href="settings.html"><i class="lni-cog"></i>Settings</a>
      </li>
    </ul>
  </div>
</div>