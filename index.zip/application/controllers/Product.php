<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Product extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->load->model('Model_db');
  }
  public function index()
  {
    redirect('home/');
  }
  public function detail($id = null, $product = null)
  {
    if (!isset($id)) {
      echo "id tidak boleh null";
    } else if (!isset($product)) {
      echo "product tidak boleh null";
    } else {
      echo "id : $id";
      echo "<br> product : " . urldecode($product);
    }
  }
  public function shopgrid()
  {
    $data = array(
      "product" => $this->Model_db->get_product('to_product', '10'),
      "title" => "TokTek | Toko Teknik Online"
    );
    $this->load->view('home/shop-grid', $data);
  }
  public function shoplist()
  {
    $data = array(
      "product" => $this->Model_db->get_product('to_product', '10'),
      "title" => "TokTek | Toko Teknik Online"
    );
    $this->load->view('home/shop-list', $data);
  }
}
