<?php
defined('BASEPATH') or exit('No direct script access allowed');
date_default_timezone_set('Asia/Jakarta');
class Proses extends CI_Controller
{
  public function __construct()
  {
    parent::__construct();
    $this->load->model('Model_db');
    $this->load->model('Model_notif');
  }
  public function upload_product()
  {
    if ((null !== $this->input->post('nama'))) {
      $config['upload_path']          = './upload/product';
      $config['allowed_types']        = 'gif|jpg|png|jpeg';
      $config['max_size']             = 100000;
      $config['max_width']            = 10000;
      $config['max_height']           = 7000;

      $this->load->library('upload', $config);

      if (!$this->upload->do_upload('image')) {
        $data = array(
          "category" => $this->Model_db->get_category('to_category', '1'),
          "title" => "Input Product | TokTek | Toko Teknik Online",
          "error" => $this->upload->display_errors(),
          "alert" => ""
        );
        $this->load->view('home/be-product', $data);
      } else {
        $upload_data = $this->upload->data();
        // id	nama	id_category	deskripsi	foto	stok	created_at	
        $data = array(
          'id' => '',
          'nama' => $this->input->post('nama'),
          'id_category' => $this->input->post('category'),
          'deskripsi' => $this->input->post('deskripsi'),
          'foto' => $upload_data['file_name'],
          'stok' => $this->input->post('stok'),
          'berat' => $this->input->post('berat'),
          'harga' => $this->input->post('harga'),
          'rating' => "0",
          'created_at' => date('Y-m-d H:i:s')
        );
        $save = $this->Model_db->create('to_product', $data);
        if ($save == true) {
          $data = array(
            "category" => $this->Model_db->get_category('to_category', '1'),
            "title" => "Input Product | TokTek | Toko Teknik Online",
            "alert" => $this->Model_notif->success('Simpan Sukses')
          );
          $this->load->view('home/be-product', $data);
        } else {
          $data = array(
            "category" => $this->Model_db->get_category('to_category', '1'),
            "title" => "Input Product | TokTek | Toko Teknik Online",
            "error" => $this->upload->display_errors(),
            "alert" => ""

          );
          $this->load->view('home/be-product', $data);
        }
        // $this->Gambar_model->create($this->upload->data());
      }
    } else {
      redirect('home/product');
    }
  }
}
